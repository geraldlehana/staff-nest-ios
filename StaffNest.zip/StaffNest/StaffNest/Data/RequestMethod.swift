//
//  RequestMethod.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/02.
//

import Foundation

enum RequestMethod: String {
    case get = "GET"
    case post = "POST"
}
