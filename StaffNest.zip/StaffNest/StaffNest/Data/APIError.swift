//
//  APIError.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/02.
//

import Foundation

enum APIError: Error {
    case invalidURL
    case networkError(Error)
    case invalidResponse
    case decodingError(Error)
    case encodingError
    case authenticationTokenNotFound
    
    var localizedDescription: String {
        switch self {
        case .invalidURL:
            return NSLocalizedString("Invalid URL", comment: "API Error: Invalid URL")
        case .networkError(let underlyingError):
            return String(format: NSLocalizedString("Network Error: %@", comment: "API Error: Network Error"), underlyingError.localizedDescription)
        case .invalidResponse:
            return NSLocalizedString("Invalid Response", comment: "API Error: Invalid Response")
        case .decodingError(let underlyingError):
            return String(format: NSLocalizedString("Decoding Error: %@", comment: "API Error: Decoding Error"), underlyingError.localizedDescription)
        case .encodingError:
            return NSLocalizedString("Encoding Error: Invalid encoding", comment: "API Error: Invalid encoding")
        case .authenticationTokenNotFound:
            return String(format: NSLocalizedString("API Error: Authentication Token not found", comment: "API Error: Token not found "))
        }
    }
}
