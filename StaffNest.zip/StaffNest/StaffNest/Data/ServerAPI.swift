//
//  ServerAPI.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

class ServerAPI {
    private let baseURL: URL
    
    init(baseURL: URL = URL(string: "https://reqres.in/api/")!) {
        self.baseURL = baseURL
    }
    
    func makeRequest<T: Decodable>(endpoint: String,
                                   method: RequestMethod,
                                   data: Data? = nil,
                                   completion: @escaping (Result<T, APIError>) -> Void) {
        
        guard let url = URL(string: endpoint, relativeTo: baseURL) else {
            completion(.failure(.invalidURL))
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method.rawValue
        
        if method == .post, let postData = data {
            request.httpBody = postData
            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                completion(.failure(.networkError(error)))
                return
            }
            
            guard let data = data else {
                completion(.failure(.invalidResponse))
                return
            }
            print(String(decoding: data, as: UTF8.self))
            do {
                let decodedData = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedData))
            } catch {
                print(error.localizedDescription)
                completion(.failure(.decodingError(error)))
            }
        }
        
        task.resume()
    }
}
