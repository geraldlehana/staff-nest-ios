//
//  LoginRepository.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

protocol LoginRepository {
    func login(with requestModel: AuthTokenRequestDTO, completion: @escaping (Result<AuthTokenResponseDTO, APIError>) -> Void)
    func saveToken(token: String)
    func retrieveToken() -> String?
}

class DefaultLoginRepository: LoginRepository {
    
    private let apiService: ServerAPI
    
    init(apiService: ServerAPI = ServerAPI()) {
        self.apiService = apiService
    }
    
    func login(with requestModel: AuthTokenRequestDTO, completion: @escaping (Result<AuthTokenResponseDTO, APIError>) -> Void) {
        let encoder = JSONEncoder()
        if let jsonData = try? encoder.encode(requestModel) {
            apiService.makeRequest(endpoint: "login", method: .post, data: jsonData, completion: completion)
        } else {
            completion(.failure(.encodingError))
        }
    }
    
    func saveToken(token: String) {
        UserDefaults.standard.set(token, forKey: "AuthToken")
    }
    
    func retrieveToken() -> String? {
        return UserDefaults.standard.string(forKey: "AuthToken")
    }
}
