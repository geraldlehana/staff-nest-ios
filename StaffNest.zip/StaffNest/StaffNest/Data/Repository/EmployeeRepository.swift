//
//  EmployeeRepository.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

protocol EmployeeRepository {
    func submitEmployeeDetails(with requestModel: UserDTO, completion: @escaping (Result<UserDTO, APIError>) -> Void)
    func getEmployees(page: Int, perPage: Int, completion: @escaping (Result<EmployeeListResponseDTO, APIError>) -> Void)
}

class DefaultEmployeeRepository: EmployeeRepository {
    private var apiService = ServerAPI()
    
    convenience init(api: ServerAPI) {
        self.init()
        self.apiService = api
    }
    
    func submitEmployeeDetails(with requestModel: UserDTO, completion: @escaping (Result<UserDTO, APIError>) -> Void) {
        let encoder = JSONEncoder()
        if let jsonData = try? encoder.encode(requestModel) {
            apiService.makeRequest(endpoint: "users", method: .post, data: jsonData, completion: completion)
        } else {
            completion(.failure(.encodingError))
        }
    }
    
    func getEmployees(page: Int, perPage: Int, completion: @escaping (Result<EmployeeListResponseDTO, APIError>) -> Void) {
        apiService.makeRequest(endpoint: "users?page=\(page)&per_page=\(perPage)", method: .get) { (result: Result<EmployeeListResponseDTO, APIError>) in
            completion(result)
        }
    }
}

