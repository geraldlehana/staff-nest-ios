//
//  ColorRepository.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

protocol ColorRepository {
    func getColors(completion: @escaping (Result<ColorListResponseDTO, APIError>) -> Void)
}

class DefaultColorRepository: ColorRepository {
    private var apiService = ServerAPI()

    convenience init(api: ServerAPI) {
        self.init()
        self.apiService = api
    }

    func getColors(completion: @escaping (Result<ColorListResponseDTO, APIError>) -> Void) {
        apiService.makeRequest(endpoint: "unknown?per_page=12", method: .get) { (result: Result<ColorListResponseDTO, APIError>) in
            completion(result)
        }
    }
}

