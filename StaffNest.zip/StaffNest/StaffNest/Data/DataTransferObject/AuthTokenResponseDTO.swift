//
//  AuthTokenResponseDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct AuthTokenResponseDTO: Codable {
    let token: String?
    let error: String?
}

struct AuthTokenRequestDTO: Codable {
    let email: String
    let password: String
}

