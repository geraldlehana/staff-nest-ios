//
//  EmployeeListResponseDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct EmployeeListResponseDTO: Codable {
    let page: Int
    let perPage: Int
    let total: Int
    let totalPages: Int
    let data: [EmployeeDTO]
    let support: SupportDTO
}
