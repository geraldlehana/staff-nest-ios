//
//  User.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/02.
//

import Foundation

struct UserDTO: Codable {
    var id: String?
    var createdAt: String?
    let userLoginToken: String
    let personalDetails: PersonalDetailsRequestDTO
    let additionalInformationRequestDTO: AdditionalInformationRequestDTO
}

struct PersonalDetailsRequestDTO: Codable {
    let id: Int
    let email: String
    let firstName: String
    let lastName: String
    let avatarURL: String
    let dateOfBirth: String
    let gender: String
    
    enum CodingKeys: String, CodingKey {
        case id, email, gender
        case firstName = "first_name"
        case lastName = "last_name"
        case avatarURL = "avatar"
        case dateOfBirth = "DOB"
    }
}

struct AdditionalInformationRequestDTO: Codable {
    let placeofBirth: String
    let preferredColor: String
    let residentialAddress: String
}
