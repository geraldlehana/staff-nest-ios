//
//  ColorListResponseDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct ColorListResponseDTO: Codable {
    let page: Int
    let perPage: Int
    let total: Int
    let totalPages: Int
    let data: [ColorDTO]
    let support: SupportDTO
}
