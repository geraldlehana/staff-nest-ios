//
//  SupportDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct SupportDTO: Codable {
    let url: String
    let text: String
}
