//
//  EmployeeDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct EmployeeDTO: Codable {
    let id: Int
    let email: String
    let firstName: String
    let lastName: String
    let avatarURL: String
    
    enum CodingKeys: String, CodingKey {
        case id, email
        case firstName = "first_name"
        case lastName = "last_name"
        case avatarURL = "avatar"
    }
}

