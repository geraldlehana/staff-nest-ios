//
//  ColorDTO.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//
import Foundation

struct ColorDTO: Codable {
    let id: Int
    let name: String
    let year: Int
    let color: String
    let pantoneValue: String
    
    enum CodingKeys: String, CodingKey {
        case id, name, year, color
        case pantoneValue = "pantone_value"
    }
}
