//
//  ColorListEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

struct ColorListEntity {
    let page: Int
    let perPage: Int
    let total: Int
    let totalPages: Int
    let colors: [ColorEntity]
}

extension ColorListEntity {
    static func transform(dto: ColorListResponseDTO) -> ColorListEntity {
        let colors = dto.data.map { ColorEntity.transform(dto: $0) }
        return ColorListEntity(
            page: dto.page,
            perPage: dto.perPage,
            total: dto.total,
            totalPages: dto.totalPages,
            colors: colors
        )
    }
}
