//
//  UserListEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

struct EmployeeListEntity {
    let page: Int
    let perPage: Int
    let total: Int
    let totalPages: Int
    let users: [EmployeeEntity]
}


extension EmployeeListEntity {
    static func transform(dto: EmployeeListResponseDTO) -> EmployeeListEntity {
        let users = dto.data.map { EmployeeEntity.transform(dto: $0) }
        return EmployeeListEntity(
            page: dto.page,
            perPage: dto.perPage,
            total: dto.total,
            totalPages: dto.totalPages,
            users: users
        )
    }
}
