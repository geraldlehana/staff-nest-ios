//
//  EmployeeEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

class EmployeeEntity {
    let id: Int
    let email: String
    let firstName: String
    let lastName: String
    let avatarURL: String
    var dateOfBirth: String?
    var gender: String?
    var placeofBirth: String?
    var preferredColor: String?
    var residentialAddress: String?

    init(id: Int, email: String, firstName: String, lastName: String, avatarURL: String) {
        self.id = id
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
        self.avatarURL = avatarURL
    }
}

extension EmployeeEntity {
    static func transform(dto: EmployeeDTO) -> EmployeeEntity {
        return EmployeeEntity(
            id: dto.id,
            email: dto.email,
            firstName: dto.firstName,
            lastName: dto.lastName,
            avatarURL: dto.avatarURL
        )
    }
    
    static func transform(entity: EmployeeEntity, withToken token: String) -> UserDTO {
        return UserDTO(
            userLoginToken: token,
            personalDetails: EmployeeEntity.transform(entity: entity),
            additionalInformationRequestDTO: EmployeeEntity.transform(entity: entity)
        )
    }
    
    static func transform(entity: EmployeeEntity) -> PersonalDetailsRequestDTO {
        return PersonalDetailsRequestDTO(
            id: entity.id,
            email: entity.email,
            firstName: entity.firstName,
            lastName: entity.lastName,
            avatarURL: entity.avatarURL,
            dateOfBirth: entity.dateOfBirth ?? "",
            gender: entity.gender ?? ""
        )
    }
    
    static func transform(entity: EmployeeEntity) -> AdditionalInformationRequestDTO {
        return AdditionalInformationRequestDTO (
            placeofBirth: entity.placeofBirth  ?? "",
            preferredColor: entity.preferredColor ?? "",
            residentialAddress: entity.residentialAddress ?? ""
        )
    }
}
