//
//  AuthenticationEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/11.
//

import Foundation

struct AuthenticationEntity: Codable {
    let token: String?
    let error: String?
}

extension AuthenticationEntity {
    static func transform(dto: AuthTokenResponseDTO) -> AuthenticationEntity {
        return AuthenticationEntity(
            token: dto.token,
            error: dto.error
        )
    }
}
