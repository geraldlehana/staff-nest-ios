//
//  SupportEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

struct SupportEntity {
    let url: String
    let text: String
}

extension SupportEntity {
    static func transform(dto: SupportDTO) -> SupportEntity {
        return SupportEntity(
            url: dto.url,
            text: dto.text
        )
    }
}
