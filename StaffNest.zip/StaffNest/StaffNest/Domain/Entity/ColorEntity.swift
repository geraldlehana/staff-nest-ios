//
//  ColorEntity.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

struct ColorEntity {
    let id: Int
    let name: String
    let year: Int
    let color: String
    let pantoneValue: String
}

extension ColorEntity {
    static func transform(dto: ColorDTO) -> ColorEntity {
        return ColorEntity(
            id: dto.id,
            name: dto.name,
            year: dto.year,
            color: dto.color,
            pantoneValue: dto.pantoneValue
        )
    }
}
