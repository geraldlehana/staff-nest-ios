//
//  StaffNestError.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//
import Foundation

enum StaffNestError: Error {
    case generic
    case incorrectCredentials
    
    var localizedDescription: String {
        switch self {
        case .generic:
            return NSLocalizedString("Generic Error", comment: "Oops! Something went wrong. Please try again.")
        case .incorrectCredentials:
            return NSLocalizedString("Incorrect Credentials", comment: "Incorrect username or password. Please try again.")
        }
    }
}

