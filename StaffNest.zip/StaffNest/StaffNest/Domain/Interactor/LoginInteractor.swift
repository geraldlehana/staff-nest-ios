//
//  LoginInteractor.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

protocol LoginInteractor {
    func login(username: String, password: String, completion: @escaping (Result<AuthenticationEntity, Error>) -> Void)
    func save(token:String?)
}

class DefaultLoginInteractor: LoginInteractor {
    private var loginRepository: LoginRepository = DefaultLoginRepository()
    
    convenience init(loginRepository: LoginRepository) {
        self.init()
        self.loginRepository = loginRepository
    }
    
    func login(username: String, password: String, completion: @escaping (Result<AuthenticationEntity, Error>) -> Void) {
        
        let request = AuthTokenRequestDTO(email: username, password: password)
        loginRepository.login(with: request) { result in
            switch result {
            case .success(let authenticationResponse):
                completion(.success(AuthenticationEntity.transform(dto: authenticationResponse)))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
    
    func save(token:String?) {
        //Log error if the token is nil
        guard let authToken = token else { return }
        loginRepository.saveToken(token: authToken)
    }
}

