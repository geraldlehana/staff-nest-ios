//
//  EmployeeInteractor.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//


import Foundation

protocol EmployeeInteractor {
    func submitEmployeeDetails(employee: EmployeeEntity, completion: @escaping (Result<String, Error>) -> Void)
    func fetchEmployeeList(page: Int, perPage: Int, completion: @escaping (Result<EmployeeListEntity, Error>) -> Void)
}

class DefaultEmployeeInteractor: EmployeeInteractor {
    private var employeeRepository: EmployeeRepository = DefaultEmployeeRepository()
    private var loginRepository: LoginRepository = DefaultLoginRepository()
    
    convenience init(employeeRepository: EmployeeRepository,
                     loginRepository: LoginRepository) {
        self.init()
        self.employeeRepository = employeeRepository
        self.loginRepository = loginRepository
    }

    func submitEmployeeDetails(employee: EmployeeEntity, completion: @escaping (Result<String, Error>) -> Void) {
        //Show user a generic error but log could not retrieve authtoken from store in the analytics logs
        guard let authToken = loginRepository.retrieveToken() else {
            completion(.failure(APIError.authenticationTokenNotFound))
            return
        }
        
        let request = EmployeeEntity.transform(entity: employee, withToken: authToken)
        employeeRepository.submitEmployeeDetails(with: request) { result in
            switch result {
            case .success(let user):
                guard let succesfullCreation = user.createdAt else {
                    completion(.failure(APIError.invalidResponse))
                    return
                }

                completion(.success(succesfullCreation))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }

    func fetchEmployeeList(page: Int, perPage: Int, completion: @escaping (Result<EmployeeListEntity, Error>) -> Void) {
        employeeRepository.getEmployees(page: 1, perPage: 12) { result in
            switch result {
            case .success(let employees):
                completion(.success(EmployeeListEntity.transform(dto: employees)))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}

