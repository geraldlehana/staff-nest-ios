//
//  ColorInteractor.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation

protocol ColorInteractor {
    func getColors(completion: @escaping (Result<ColorListEntity, Error>) -> Void)
}

class DefaultColorInteractor: ColorInteractor {
    private var colorListRepository:ColorRepository = DefaultColorRepository ()
    
    convenience init(colorListRepository: ColorRepository) {
        self.init()
        self.colorListRepository = colorListRepository
    }
    
    func getColors(completion: @escaping (Result<ColorListEntity, Error>) -> Void) {
        colorListRepository.getColors{ result in
            switch result {
            case .success(let colors):
                completion(.success(ColorListEntity.transform(dto: colors)))
            case .failure(let error):
                completion(.failure(error))
            }
        }
    }
}

