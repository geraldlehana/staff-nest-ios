//
//  EmployeeListViewModel.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation

protocol EmployeeListViewModel: ViewControllerLifecycleViewModel, AnyObject {
    var view: EmloyeeListTableViewControllerDelegate? { get set }
    func cellTapped()
}

final class DefaultEmployeeListViewModel: EmployeeListViewModel {
    private var empInteractor: EmployeeInteractor = DefaultEmployeeInteractor()
    internal weak var view: EmloyeeListTableViewControllerDelegate?
    
    func cellTapped() {
        view?.popScreen()
    }
    
}

// MARK: - ViewControllerLifecycleViewModel
extension DefaultEmployeeListViewModel: ViewControllerLifecycleViewModel {
    @objc func viewDidLoad() {
        view?.setUpView()
    }
}

