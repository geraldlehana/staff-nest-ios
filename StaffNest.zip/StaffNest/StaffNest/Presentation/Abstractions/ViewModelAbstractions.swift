//
//  ViewModelAbstractions.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation
import UIKit

@objc protocol ViewControllerLifecycleViewModel {
    func viewDidLoad()
    @objc optional func viewWillAppear()
    @objc optional func viewDidDisappear()
    @objc optional func viewWillDisappear()
}

protocol DataSourceViewModel {
    func numberOfSections() -> Int
    func numberOfRows(in section: Int) -> Int
}

protocol TableViewViewModel: DataSourceViewModel {
    func didSelectRow(at indexPath: IndexPath)
}

protocol CollectionViewViewModel: DataSourceViewModel {
    func sizeForItem(at indexPath: IndexPath) -> CGSize
    func didSelectItem(at indexPath: IndexPath)
    func minimumLineSpacing(at section: Int) -> CGFloat
    func minimumInteritemSpacing(at section: Int) -> CGFloat
    func sizeForHeader(at section: Int) -> CGSize
    func sizeForFooter(at section: Int) -> CGSize
}

protocol ViewControllerConfig {
    var title: String { get set }
    var backgroundColor: UIColor { get set }
}

protocol RetryViewViewModel {
    func retryButtonPressed()
}
