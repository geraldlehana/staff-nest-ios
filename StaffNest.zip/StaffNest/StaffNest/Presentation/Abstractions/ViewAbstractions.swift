//
//  ViewAbstractions.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation

protocol LoadingView {
    func displayLoading()
    func dismissLoading()
}

protocol RetryView {
    func displayRetry()
}

protocol TableView {
    func reloadData()
}

protocol ViewControler {
    func presentDialogWith(title: String, message: String)
}
