//
//  StatusViewModel.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation
