//
//  EmployeeViewController.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import UIKit

protocol EmployeeViewControllerDelegate: AnyObject, UIViewController, ViewControler {
    func presenEmployeeListScreen()
    func setUpView()
}

class EmployeeViewController: UIViewController {
    @IBOutlet weak var dob: UITextField!
    @IBOutlet weak var pob: UITextField!
    
    @IBOutlet weak var empSelectionView: UIView!
    @IBOutlet weak var fullname: UILabel!
    @IBOutlet weak var email: UILabel!
    
    //would prefer to inject optionally
    private var viewModel: EmployeeViewModel = DefaultEmployeeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.view = self
        viewModel.viewDidLoad()
    }
    
    // MARK: - Actions
    @objc func nextButtonTapped() {
        viewModel.nextButtonPressedWith(dob: dob.text, pob: pob.text)
    }
    
    @objc func viewTapped() {
        viewModel.viewSelectionTapped()
    }
}

extension EmployeeViewController: EmployeeViewControllerDelegate {
    func setUpView() {
        //Ideally we should read and assign copy text from view model and localization
        let nextButton = UIBarButtonItem(title: "Next", style: .plain, target: self, action: #selector(nextButtonTapped))
        nextButton.tintColor = .black
        navigationItem.rightBarButtonItem = nextButton
        self.title = "Employee"
        
        empSelectionView.isUserInteractionEnabled = true
        let tapRecognizer = UITapGestureRecognizer(target: self, action: #selector(viewTapped))
        empSelectionView.addGestureRecognizer(tapRecognizer)
    }
    
    func presenEmployeeListScreen() {
        let screen = EmloyeeListTableViewController()
        let nav = UINavigationController(rootViewController: screen)
        present(nav, animated: true)
    }
}
