//
//  EmployeeViewModel.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation

protocol EmployeeViewModel: ViewControllerLifecycleViewModel, AnyObject {
    var view: EmployeeViewControllerDelegate? { get set }
    func nextButtonPressedWith(dob: String?, pob: String?)
    func viewSelectionTapped()
}

final class DefaultEmployeeViewModel: EmployeeViewModel {
    private var empInteractor: EmployeeInteractor = DefaultEmployeeInteractor()
    internal weak var view: EmployeeViewControllerDelegate?
    private var employee: EmployeeEntity?
    
    func nextButtonPressedWith(dob: String?, pob: String?) {
        
        guard
            let dateOfBirth = dob, !dateOfBirth.isEmpty,
            let placeOfBirth = pob, !placeOfBirth.isEmpty,
            let employee = employee
        else { return }
        
        employee.dateOfBirth = dateOfBirth
        employee.placeofBirth = placeOfBirth
        //TODO: Pass the entity from emp list screen
    }
    
    func viewSelectionTapped() {
        view?.presenEmployeeListScreen()
    }
    private func handleLoginFailed(with error: Error) {
        view?.presentDialogWith(title: "Oops yikes", message: error.localizedDescription)
    }
}

// MARK: - ViewControllerLifecycleViewModel
extension DefaultEmployeeViewModel: ViewControllerLifecycleViewModel {
    @objc func viewDidLoad() {
        view?.setUpView()
    }
}
