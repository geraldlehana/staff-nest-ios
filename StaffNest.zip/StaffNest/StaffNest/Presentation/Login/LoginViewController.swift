//
//  LoginViewController.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/01.
//

import UIKit

protocol LoginViewControllerDelegate: AnyObject, UIViewController, ViewControler {
    func pushToEmployeeSelectionScreen()
    func setUpView()
}

final class LoginViewController: UIViewController {

    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    
    //would prefer to inject optionally
    private var viewModel: LoginViewModel = DefaultLoginViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.view = self
        viewModel.viewDidLoad()
    }
    
    @IBAction func loginAction(_ sender: Any) {
        print("login tapped")
        viewModel.loginButtonPressedWith(username: email.text, password: password.text)
    }
}

extension LoginViewController: LoginViewControllerDelegate {
    func setUpView() {
        email.textContentType = .username
        password.textContentType = .password
        password.isSecureTextEntry = true
        
        email.text = "eve.holt@reqres.in"
        password.text = "cityslickaw"
    }
    
    func pushToEmployeeSelectionScreen() {
        let screen = EmployeeViewController()
        let nav = UINavigationController(rootViewController: screen)
        self.view.window?.rootViewController = nav
        self.view.window?.makeKeyAndVisible()
    }
    
    
}

extension UIViewController: ViewControler {
    func presentDialogWith(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "Ok", style: .cancel)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}

//TODO: Need an activity Indicator view
