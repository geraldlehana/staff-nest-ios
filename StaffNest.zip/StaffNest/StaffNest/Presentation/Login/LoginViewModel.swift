//
//  LoginViewModel.swift
//  StaffNest
//
//  Created by Gerald Lehana on 2024/02/12.
//

import Foundation

protocol LoginViewModel: ViewControllerLifecycleViewModel, AnyObject {
    var view: LoginViewControllerDelegate? { get set }
    func loginButtonPressedWith(username: String?, password: String?)
}

final class DefaultLoginViewModel: LoginViewModel {
    private var authInteractor: LoginInteractor = DefaultLoginInteractor()
    internal weak var view: LoginViewControllerDelegate?
    
    
    func loginButtonPressedWith(username: String?, password: String?) {
        guard
            let uCred = username, !uCred.isEmpty,
            let uPass = password, !uPass.isEmpty
        else { return }
        
        authInteractor.login(username: uCred, password: uPass, completion: { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    self?.handleSuccessfulResponse(with: response)
                case .failure(let error):
                    self?.handleLoginFailed(with: error)
                }
            }
        })
    }
    
    private func handleLoginFailed(with error: Error) {
        view?.presentDialogWith(title: "Oops yikes", message: error.localizedDescription)
    }
    
    private func handleSuccessfulResponse(with response: AuthenticationEntity) {
        if let errorMessage = response.error {
            view?.presentDialogWith(title: "Error", message: errorMessage)
        } else {
            authInteractor.save(token: response.token)
            view?.pushToEmployeeSelectionScreen()
        }
    }
}

// MARK: - ViewControllerLifecycleViewModel
extension DefaultLoginViewModel: ViewControllerLifecycleViewModel {
    @objc func viewDidLoad() {
        view?.setUpView()
    }
}
