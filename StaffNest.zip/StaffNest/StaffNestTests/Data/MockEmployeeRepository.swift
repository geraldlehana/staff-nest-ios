//
//  MockEmployeeRepository.swift
//  StaffNestTests
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation
import StaffNest

//class MockEmployeeRepository: EmployeeRepository {
//    private var employees: [EmployeeInfo]
//
//    init() {
//        if let path = Bundle.main.path(forResource: "employees", ofType: "json"),
//           let jsonData = try? Data(contentsOf: URL(fileURLWithPath: path)) {
//            do {
//                self.employees = try JSONDecoder().decode([EmployeeInfo].self, from: jsonData)
//            } catch {
//                // Handle decoding error
//                self.employees = []
//            }
//        } else {
//            // Handle file not found or invalid JSON
//            self.employees = []
//        }
//    }
//
//    func submitEmployeeDetails(employee: EmployeeInfo, completion: @escaping (Result<EmployeeSubmissionResponse, Error>) -> Void) {
//        // Handle submission logic if needed
//        // For mock purposes, just return success
//        let response = EmployeeSubmissionResponse(status: "Success")
//        completion(.success(response))
//    }
//
//    func getEmployees(page: Int, perPage: Int, completion: @escaping (Result<EmployeeListResponse, Error>) -> Void) {
//        let response = EmployeeListResponse(employees: employees)
//        completion(.success(response))
//    }
//}

