//
//  APIErrorTests.swift
//  StaffNestTests
//
//  Created by Gerald Lehana on 2024/02/02.
//

import XCTest
@testable import StaffNest

final class APIErrorTests: XCTestCase {
    
    func testInvalidURL() {
            let error = APIError.invalidURL
            XCTAssertEqual(error.localizedDescription, "Invalid URL")
        }
        
        func testNetworkError() {
            let underlyingError = NSError(domain: "TestDomain", code: 42, userInfo: nil)
            let error = APIError.networkError(underlyingError)
            XCTAssertEqual(error.localizedDescription, "Network Error: The operation couldn’t be completed. (TestDomain error 42.)")
        }
        
        func testInvalidResponse() {
            let error = APIError.invalidResponse
            XCTAssertEqual(error.localizedDescription, "Invalid Response")
        }
        
        func testDecodingError() {
            let underlyingError = NSError(domain: "TestDomain", code: 43, userInfo: nil)
            let error = APIError.decodingError(underlyingError)
            XCTAssertEqual(error.localizedDescription, "Decoding Error: The operation couldn’t be completed. (TestDomain error 43.)")
        }
        
        func testEncodingError() {
            let error = APIError.encodingError
            XCTAssertEqual(error.localizedDescription, "Encoding Error")
        }
        
        func testAuthenticationTokenNotFound() {
            let token = "123456"
            let error = APIError.authenticationTokenNotFound
            XCTAssertEqual(error.localizedDescription, "API Error: Authentication Token not found")
        }
    
}
