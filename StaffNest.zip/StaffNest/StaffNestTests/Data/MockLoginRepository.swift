//
//  MockLoginRepository.swift
//  StaffNestTests
//
//  Created by Gerald Lehana on 2024/02/01.
//

import Foundation
import StaffNest

//class MockLoginRepository: LoginRepository {
//    
//}
